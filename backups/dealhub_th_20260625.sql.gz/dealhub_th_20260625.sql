-- MySQL dump 10.13  Distrib 9.3.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: dealhub_th
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('421b6bf4-6850-4459-aef5-4ce39c86d03e','a4eb24e56a611a73d7b850f846ebd66e3ab0297988726724fc679b092f9f1f95','2026-06-25 05:40:34.936','20260622190000_board',NULL,NULL,'2026-06-25 05:40:34.714',1),('b1406fa0-b545-47b2-b734-248bb981fce8','c8761e95eee13a04cefa5f3488ef04025e7e1723b3b20d63e8b6901f8ab7befc','2026-06-22 14:40:22.740','20260622144022_init',NULL,NULL,'2026-06-22 14:40:22.433',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `affiliate_clicks`
--

DROP TABLE IF EXISTS `affiliate_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_clicks` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marketplace` enum('SHOPEE','LAZADA','TIKTOK_SHOP','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `referrer` text COLLATE utf8mb4_unicode_ci,
  `clicked_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `affiliate_clicks_product_id_idx` (`product_id`),
  KEY `affiliate_clicks_clicked_at_idx` (`clicked_at`),
  KEY `affiliate_clicks_marketplace_idx` (`marketplace`),
  KEY `affiliate_clicks_user_id_fkey` (`user_id`),
  CONSTRAINT `affiliate_clicks_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `affiliate_clicks_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affiliate_clicks`
--

LOCK TABLES `affiliate_clicks` WRITE;
/*!40000 ALTER TABLE `affiliate_clicks` DISABLE KEYS */;
INSERT INTO `affiliate_clicks` VALUES ('cmqpc8t7000012epw75qlhe1u',NULL,'cmqpbom33001g2evz15ytxzog','SHOPEE',NULL,NULL,NULL,'2026-06-22 14:56:11.723');
/*!40000 ALTER TABLE `affiliate_clicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_comments`
--

DROP TABLE IF EXISTS `board_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_comments` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `board_comments_post_id_created_at_idx` (`post_id`,`created_at`),
  KEY `board_comments_user_id_fkey` (`user_id`),
  CONSTRAINT `board_comments_post_id_fkey` FOREIGN KEY (`post_id`) REFERENCES `board_posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `board_comments_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_comments`
--

LOCK TABLES `board_comments` WRITE;
/*!40000 ALTER TABLE `board_comments` DISABLE KEYS */;
INSERT INTO `board_comments` VALUES ('cmqt2py9r00412el95wkvor73','cmqt2py9m003z2el9g9rqz32r','cmqt2py8o003i2el9an3gwzfd','ผมเลือก XM5 เพราะเดินทางบ่อย ตัดเสียงเครื่องบินได้ดีมาก','2026-06-25 04:10:39.999'),('cmqt2py9u00432el912t8li5h','cmqt2py9m003z2el9g9rqz32r','cmqt2py8u003m2el9jeamvx6j','QC45 ราคา TikTok Shop ถูกกว่า Shopee วันนี้ ลองเช็คดูครับ','2026-06-25 04:40:40.002'),('cmqt2py9v00452el963338b72','cmqt2py9m003z2el9g9rqz32r','cmqt2py8s003l2el98ifbrxp2','ขอบคุณมาก กำลังลังเลอยู่พอดี','2026-06-25 05:10:40.003'),('cmqt2pya000492el91y93y0f2','cmqt2py9w00472el9urluxst6','cmqt2py8v003n2el95vzbw8r6','Biore UV สีฟ้า ใช้ดีมาก ราคาไม่เกิน 300','2026-06-25 02:40:40.007'),('cmqt2pya1004b2el9bfjvtzv3','cmqt2py9w00472el9urluxst6','cmqt2py8x003o2el9jodfe56j','เห็นด้วยค่ะ ซื้อจาก Shopee Mall ของแท้ชัวร์','2026-06-25 03:40:40.009'),('cmqt2pya3004f2el9rqi0d1cy','cmqt2pya2004d2el9dy0n16xt','cmqt2py8y003p2el9obn02xbi','TikTok ถูกกว่าแต่เช็คร้านให้ดี แนะนำร้านที่มี rating 4.8+','2026-06-25 00:40:40.011'),('cmqt2pya6004l2el9249r1wqy','cmqt2pya5004j2el99wwrlhj6','cmqt2py8u003m2el9jeamvx6j','เจอครับ ขอคืนเงินได้แต่ต้องรอ 3-5 วัน','2026-06-25 04:52:40.013'),('cmqt2pya6004n2el9aizo9e8b','cmqt2pya5004j2el99wwrlhj6','cmqt2py8j003h2el9d9q3cqwa','เลยชอบซื้อร้านที่มีรีวิวเยอะและมีวิดีโอจริง','2026-06-25 05:22:40.014'),('cmqt2pya9004t2el9e4re2e5y','cmqt2pya8004r2el9n1zasvke','cmqt2py8o003i2el9an3gwzfd','แบตหมดเร็วไหมคะ อยากรู้ก่อนซื้อ','2026-06-25 01:40:40.017'),('cmqt2pyaa004x2el92ow4pme5','cmqt2pyaa004v2el90m1cpl0c','cmqt2py8j003h2el9d9q3cqwa','เข้าหน้าสินค้าแล้วเลื่อนลงดูกราฟประวัติราคาได้เลยครับ','2026-06-24 18:40:40.018'),('cmqt2pyac00532el9trxvaww5','cmqt2pyab00512el925ksy36o','cmqt2py8p003j2el9h8f7d49g','ตั้งแจ้งเตือนไว้แล้ว ขอบคุณที่แชร์!','2026-06-25 05:22:40.020'),('cmqt2pyad00552el9d1vcjq81','cmqt2pyab00512el925ksy36o','cmqt2py8r003k2el9t3ujcvrk','Shopee ลดมากกว่า แต่ Lazada มีคูปองส่งฟรี','2026-06-25 05:28:40.021');
/*!40000 ALTER TABLE `board_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_groups`
--

DROP TABLE IF EXISTS `board_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_groups` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bg` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `board_groups_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_groups`
--

LOCK TABLES `board_groups` WRITE;
/*!40000 ALTER TABLE `board_groups` DISABLE KEYS */;
INSERT INTO `board_groups` VALUES ('cmqt2py90003q2el9iixy02d4','variety','บอร์ดวาไรตี้','💬','สนทนาทั่วไป แชร์ประสบการณ์ช้อปออนไลน์','#EE4D2D','#FEF0ED',1,'2026-06-25 05:40:39.973'),('cmqt2py93003r2el9zkn4z8ib','recommend','แนะนำสินค้า','⭐','รวมของดีที่อยากแนะนำให้เพื่อนๆ','#F57C00','#FFF3E0',2,'2026-06-25 05:40:39.976'),('cmqt2py95003s2el9efiajorc','compare','เทียบราคา','⚖️','เปรียบเทียบราคาข้าม Shopee · Lazada · TikTok','#1565C0','#E3F2FD',3,'2026-06-25 05:40:39.977'),('cmqt2py96003t2el9do0voung','deals','ดีล & โปรโมชั่น','🏷️','แจ้ง Flash Sale คูปอง และโปรเด็ดประจำวัน','#D4006A','#FCE4EC',4,'2026-06-25 05:40:39.979'),('cmqt2py98003u2el9jsqbibd8','review','ใช้จริงรีวิว','📝','รีวิวหลังใช้งานจริง ไม่โม้ ไม่กั๊ก','#2E7D32','#E8F5E9',5,'2026-06-25 05:40:39.980'),('cmqt2py9b003v2el90547qcwx','ask','ถามก่อนซื้อ','❓','สงสัยอะไรถามได้ ชุมชนช่วยตอบ','#6A1B9A','#F3E5F5',6,'2026-06-25 05:40:39.983'),('cmqt2py9c003w2el91fuxlnc3','lifestyle','ไลฟ์สไตล์','🏡','WFH, ความงาม, บ้านและของใช้ในชีวิตประจำวัน','#00838F','#E0F7FA',7,'2026-06-25 05:40:39.985'),('cmqt2py9e003x2el9rf6hpy2w','newbie','มือใหม่หัดช้อป','🌱','คำแนะนำพื้นฐานสำหรับคนเริ่มช้อปออนไลน์','#558B2F','#F1F8E9',8,'2026-06-25 05:40:39.987');
/*!40000 ALTER TABLE `board_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_post_upvotes`
--

DROP TABLE IF EXISTS `board_post_upvotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_post_upvotes` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `board_post_upvotes_post_id_user_id_key` (`post_id`,`user_id`),
  KEY `board_post_upvotes_user_id_fkey` (`user_id`),
  CONSTRAINT `board_post_upvotes_post_id_fkey` FOREIGN KEY (`post_id`) REFERENCES `board_posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `board_post_upvotes_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_post_upvotes`
--

LOCK TABLES `board_post_upvotes` WRITE;
/*!40000 ALTER TABLE `board_post_upvotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_post_upvotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_posts`
--

DROP TABLE IF EXISTS `board_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_posts` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `body` text COLLATE utf8mb4_unicode_ci,
  `upvote_count` int NOT NULL DEFAULT '0',
  `comment_count` int NOT NULL DEFAULT '0',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `board_posts_group_id_created_at_idx` (`group_id`,`created_at`),
  KEY `board_posts_is_hot_idx` (`is_hot`),
  KEY `board_posts_upvote_count_idx` (`upvote_count`),
  KEY `board_posts_user_id_fkey` (`user_id`),
  KEY `board_posts_product_id_fkey` (`product_id`),
  CONSTRAINT `board_posts_group_id_fkey` FOREIGN KEY (`group_id`) REFERENCES `board_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `board_posts_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `board_posts_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_posts`
--

LOCK TABLES `board_posts` WRITE;
/*!40000 ALTER TABLE `board_posts` DISABLE KEYS */;
INSERT INTO `board_posts` VALUES ('cmqt2py9m003z2el9g9rqz32r','cmqt2py95003s2el9efiajorc','cmqt2py8j003h2el9d9q3cqwa',NULL,'เปรียบ Sony XM5 vs Bose QC45 ใช้จริง 3 เดือน ราคาต่างกัน 2K คุ้มไหม?','สรุปสั้นๆ: XM5 เก็บเสียงรอบข้างดีกว่า แต่ QC45 ใส่สบายกว่า...','ใช้ทั้งคู่มา 3 เดือน WFH ทุกวัน สรุปว่า XM5 ตัดเสียงรอบข้างได้ดีกว่าชัดเจน แต่ QC45 ใส่ทั้งวันไม่เจ็บหู ราคาต่างกัน ~2,000 บาท ถ้าซื้อที่ Lazada มีคูปองลดเพิ่มอีก',342,3,1,'2026-06-25 03:40:39.993','2026-06-25 03:40:39.993'),('cmqt2py9w00472el9urluxst6','cmqt2py93003r2el9zkn4z8ib','cmqt2py8o003i2el9an3gwzfd',NULL,'แนะนำครีมกันแดดราคาไม่เกิน 500 บาท ที่ซื้อซ้ำมาแล้ว 5 ครั้ง 🌞','เน้นตัวที่ไม่เหนอะหน้า ทาแล้วไม่อุดตัน ใช้ได้ทุกวัน',NULL,218,2,1,'2026-06-25 01:40:40.004','2026-06-25 01:40:40.004'),('cmqt2pya2004d2el9dy0n16xt','cmqt2py96003t2el9do0voung','cmqt2py8p003j2el9h8f7d49g',NULL,'PS5 Slim ราคา Lazada vs TikTok Shop วันนี้ต่างกัน 890 บาท! ซื้อที่ไหนดี',NULL,NULL,196,1,1,'2026-06-24 23:40:40.010','2026-06-24 23:40:40.010'),('cmqt2pya4004h2el9cw78mlia','cmqt2py9c003w2el91fuxlnc3','cmqt2py8r003k2el9t3ujcvrk',NULL,'สรุป 10 อุปกรณ์ทำงาน WFH ราคาดีที่สุด Shopee เดือนนี้ 💻',NULL,NULL,154,0,1,'2026-06-24 21:40:40.012','2026-06-24 21:40:40.012'),('cmqt2pya5004j2el99wwrlhj6','cmqt2py90003q2el9iixy02d4','cmqt2py8s003l2el98ifbrxp2',NULL,'ใครเคยสั่งของ TikTok Shop แล้วของไม่ตรงปกบ้าง? แชร์ประสบการณ์หน่อย',NULL,NULL,127,2,0,'2026-06-25 04:40:40.013','2026-06-25 04:40:40.013'),('cmqt2pya7004p2el9bz8pu80i','cmqt2py9b003v2el90547qcwx','cmqt2py8u003m2el9jeamvx6j',NULL,'จะซื้อ iPad ตัวแรก ควรเอา Air หรือ Pro ดี? งบไม่เกิน 25K',NULL,NULL,89,0,0,'2026-06-25 02:40:40.015','2026-06-25 02:40:40.015'),('cmqt2pya8004r2el9n1zasvke','cmqt2py98003u2el9jsqbibd8','cmqt2py8v003n2el95vzbw8r6','cmqt1ekh9001a2eknae4orf8u','ใช้ Dyson V12 มา 6 เดือน สรุปข้อดีข้อเสียที่ไม่มีใครบอก',NULL,NULL,176,1,1,'2026-06-25 00:40:40.016','2026-06-25 00:40:40.016'),('cmqt2pyaa004v2el90m1cpl0c','cmqt2py9e003x2el9rf6hpy2w','cmqpbom0u00012evzje7n0twb',NULL,'มือใหม่ ถามวิธีเช็คราคาย้อนหลังก่อนซื้อใน DealHub ทำยังไง?',NULL,NULL,45,1,0,'2026-06-24 17:40:40.018','2026-06-24 17:40:40.018'),('cmqt2pyab004z2el9f74niwl3','cmqt2py93003r2el9zkn4z8ib','cmqt2py8x003o2el9jodfe56j',NULL,'รวม 7 รองเท้าผ้าใบ ราคาไม่เกิน 1,500 ใส่สบาย เดินทั้งวันไม่เจ็บ',NULL,NULL,203,0,1,'2026-06-24 22:40:40.019','2026-06-24 22:40:40.019'),('cmqt2pyab00512el925ksy36o','cmqt2py96003t2el9do0voung','cmqt2py8y003p2el9obn02xbi',NULL,'🔥 Flash Sale เที่ยงคืนนี้! หูฟังลด 60% ทั้ง Shopee และ Lazada',NULL,NULL,312,2,1,'2026-06-25 05:10:40.019','2026-06-25 05:10:40.019'),('cmqt2pyae00572el9nqk82zr1','cmqt2py9b003v2el90547qcwx','cmqt2py8o003i2el9an3gwzfd',NULL,'อยากได้ Air Fryer ตัวแรก Philips กับ Tefal อันไหนคุ้มกว่า?',NULL,NULL,67,0,0,'2026-06-25 05:25:40.022','2026-06-25 05:25:40.022'),('cmqt2pyaf00592el9ycn6jzis','cmqt2py95003s2el9efiajorc','cmqt2py8s003l2el98ifbrxp2',NULL,'Stanley แท้ vs ของเลียนแบบ TikTok เก็บความเย็นต่างกันแค่ไหน?',NULL,NULL,134,0,0,'2026-06-25 04:10:40.022','2026-06-25 04:10:40.022');
/*!40000 ALTER TABLE `board_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_key` (`slug`),
  KEY `categories_parent_id_idx` (`parent_id`),
  KEY `categories_slug_idx` (`slug`),
  CONSTRAINT `categories_parent_id_fkey` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES ('cmqpbom0z00022evz98qcokba','อิเล็กทรอนิกส์','electronics','เทียบราคาสมาร์ทโฟน แท็บเล็ต หูฟัง และอุปกรณ์อิเล็กทรอนิกส์ จาก Shopee Lazada TikTok Shop หาราคาดีที่สุดก่อนซื้อ','📱',NULL,NULL,1,1,'2026-06-22 14:40:29.315','2026-06-25 05:40:39.576'),('cmqpbom1300032evzyzzrdjo7','แฟชั่น','fashion','แฟชั่นและเสื้อผ้าแบรนด์ดัง เปรียบเทียบราคาจากทุกแพลตฟอร์ม อัปเดตโปรโมชั่นและดีลล่าสุดทุกวัน','👗',NULL,NULL,2,1,'2026-06-22 14:40:29.315','2026-06-25 05:40:39.576'),('cmqpbom1300042evzytiqje7k','บ้านและที่อยู่อาศัย','home-living','เฟอร์นิเจอร์ ของใช้ในบ้าน และเครื่องใช้ไฟฟ้า เลือกซื้อในราคาคุ้มค่าจากหลายแพลตฟอร์ม','🏠',NULL,NULL,4,1,'2026-06-22 14:40:29.315','2026-06-25 05:40:39.576'),('cmqpbom1400052evz8s5b55h2','ความงาม','beauty','สกินแคร์ เครื่องสำอาง และผลิตภัณฑ์บำรุงความงาม เทียบราคาจากร้านค้าออนไลน์ชั้นนำในที่เดียว','💄',NULL,NULL,3,1,'2026-06-22 14:40:29.315','2026-06-25 05:40:39.576'),('cmqpbom1500062evzih8qqaoj','กีฬาและกลางแจ้ง','sports','อุปกรณ์กีฬาและกิจกรรมกลางแจ้ง เทียบราคาและโปรโมชั่นจาก Shopee Lazada TikTok Shop','⚽',NULL,NULL,5,1,'2026-06-22 14:40:29.315','2026-06-25 05:40:39.576');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compare_items`
--

DROP TABLE IF EXISTS `compare_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compare_items` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `compare_list_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `compare_items_compare_list_id_product_id_key` (`compare_list_id`,`product_id`),
  KEY `compare_items_product_id_fkey` (`product_id`),
  CONSTRAINT `compare_items_compare_list_id_fkey` FOREIGN KEY (`compare_list_id`) REFERENCES `compare_lists` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `compare_items_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compare_items`
--

LOCK TABLES `compare_items` WRITE;
/*!40000 ALTER TABLE `compare_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `compare_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compare_lists`
--

DROP TABLE IF EXISTS `compare_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compare_lists` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `compare_lists_user_id_fkey` (`user_id`),
  CONSTRAINT `compare_lists_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compare_lists`
--

LOCK TABLES `compare_lists` WRITE;
/*!40000 ALTER TABLE `compare_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `compare_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_alerts`
--

DROP TABLE IF EXISTS `price_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_alerts` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_price` decimal(12,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `notified_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `price_alerts_user_id_idx` (`user_id`),
  KEY `price_alerts_is_active_idx` (`is_active`),
  KEY `price_alerts_product_id_fkey` (`product_id`),
  CONSTRAINT `price_alerts_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `price_alerts_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_alerts`
--

LOCK TABLES `price_alerts` WRITE;
/*!40000 ALTER TABLE `price_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_history`
--

DROP TABLE IF EXISTS `price_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_history` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `listing_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `recorded_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `price_history_product_id_recorded_at_idx` (`product_id`,`recorded_at`),
  KEY `price_history_listing_id_recorded_at_idx` (`listing_id`,`recorded_at`),
  CONSTRAINT `price_history_listing_id_fkey` FOREIGN KEY (`listing_id`) REFERENCES `product_listings` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `price_history_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_history`
--

LOCK TABLES `price_history` WRITE;
/*!40000 ALTER TABLE `price_history` DISABLE KEYS */;
INSERT INTO `price_history` VALUES ('cmqpbom1s000c2evzs2ktebbu','cmqpbom1900082evz6iiov08a',NULL,45900.00,'2026-06-22 14:40:29.343'),('cmqpbom1x000g2evzceupmxn0','cmqpbom1900082evz6iiov08a',NULL,46500.00,'2026-06-22 14:40:29.349'),('cmqpbom23000k2evzjsrcc970','cmqpbom1900082evz6iiov08a',NULL,45200.00,'2026-06-22 14:40:29.355'),('cmqpbom29000q2evzo6505uhu','cmqpbom25000m2evzs6dc60zi',NULL,38900.00,'2026-06-22 14:40:29.361'),('cmqpbom2d000u2evzkvo6r152','cmqpbom25000m2evzs6dc60zi',NULL,39500.00,'2026-06-22 14:40:29.365'),('cmqpbom2k00102evzpg1fp0d5','cmqpbom2e000w2evztr73e5mi',NULL,199.00,'2026-06-22 14:40:29.372'),('cmqpbom2o00142evz7zlwyswr','cmqpbom2e000w2evztr73e5mi',NULL,179.00,'2026-06-22 14:40:29.376'),('cmqpbom2w001a2evzz5myy33b','cmqpbom2r00162evzqjn6asfv',NULL,299.00,'2026-06-22 14:40:29.384'),('cmqpbom32001e2evz46b2wnvk','cmqpbom2r00162evzqjn6asfv',NULL,320.00,'2026-06-22 14:40:29.390'),('cmqpbom38001k2evzno0b1am4','cmqpbom33001g2evz15ytxzog',NULL,1290.00,'2026-06-22 14:40:29.396'),('cmqpbom3c001o2evzbcqzvmfv','cmqpbom33001g2evz15ytxzog',NULL,1350.00,'2026-06-22 14:40:29.400'),('cmqpbom3g001s2evzsv10ta2s','cmqpbom33001g2evz15ytxzog',NULL,1190.00,'2026-06-22 14:40:29.403'),('cmqpbom3m001y2evzl6td94ih','cmqpbom3i001u2evz7ij96oum',NULL,12900.00,'2026-06-22 14:40:29.409'),('cmqpbom3q00222evz6yto5w2s','cmqpbom3i001u2evz7ij96oum',NULL,13500.00,'2026-06-22 14:40:29.414'),('cmqpc1rzm000c2efftugyn26w','cmqpbom1900082evz6iiov08a',NULL,45900.00,'2026-06-22 14:50:43.569'),('cmqpc1rzs000g2eff5z8lb96s','cmqpbom1900082evz6iiov08a',NULL,46500.00,'2026-06-22 14:50:43.576'),('cmqpc1rzv000k2effojibucew','cmqpbom1900082evz6iiov08a',NULL,45200.00,'2026-06-22 14:50:43.579'),('cmqpc1rzz000q2effybgfny1v','cmqpbom25000m2evzs6dc60zi',NULL,38900.00,'2026-06-22 14:50:43.583'),('cmqpc1s01000u2effz0zlghbu','cmqpbom25000m2evzs6dc60zi',NULL,39500.00,'2026-06-22 14:50:43.585'),('cmqpc1s0600102effgzwdqtsj','cmqpbom2e000w2evztr73e5mi',NULL,199.00,'2026-06-22 14:50:43.590'),('cmqpc1s0800142eff2u6dqxt2','cmqpbom2e000w2evztr73e5mi',NULL,179.00,'2026-06-22 14:50:43.592'),('cmqpc1s0d001a2effxlf2izdt','cmqpbom2r00162evzqjn6asfv',NULL,299.00,'2026-06-22 14:50:43.597'),('cmqpc1s0i001e2effukzt71fj','cmqpbom2r00162evzqjn6asfv',NULL,320.00,'2026-06-22 14:50:43.602'),('cmqpc1s0p001k2effgb243ncw','cmqpbom33001g2evz15ytxzog',NULL,1290.00,'2026-06-22 14:50:43.608'),('cmqpc1s0s001o2eff1elakw15','cmqpbom33001g2evz15ytxzog',NULL,1350.00,'2026-06-22 14:50:43.612'),('cmqpc1s0v001s2eff0fsfnf5q','cmqpbom33001g2evz15ytxzog',NULL,1190.00,'2026-06-22 14:50:43.615'),('cmqpc1s0z001y2effa9kwp12k','cmqpbom3i001u2evz7ij96oum',NULL,12900.00,'2026-06-22 14:50:43.619'),('cmqpc1s1400222effly3o9jgs','cmqpbom3i001u2evz7ij96oum',NULL,13500.00,'2026-06-22 14:50:43.624'),('cmqpc6ku4000c2ea9nea1x54g','cmqpbom1900082evz6iiov08a',NULL,45900.00,'2026-06-22 14:54:27.579'),('cmqpc6ku9000g2ea9zdkfn3pi','cmqpbom1900082evz6iiov08a',NULL,46500.00,'2026-06-22 14:54:27.585'),('cmqpc6kud000k2ea9g01jmzsj','cmqpbom1900082evz6iiov08a',NULL,45200.00,'2026-06-22 14:54:27.589'),('cmqpc6kuh000q2ea9led2jfzt','cmqpbom25000m2evzs6dc60zi',NULL,38900.00,'2026-06-22 14:54:27.593'),('cmqpc6kuk000u2ea9wvzbbtim','cmqpbom25000m2evzs6dc60zi',NULL,39500.00,'2026-06-22 14:54:27.596'),('cmqpc6kup00102ea9lq603khg','cmqpbom2e000w2evztr73e5mi',NULL,199.00,'2026-06-22 14:54:27.601'),('cmqpc6kut00142ea9ggof2pbz','cmqpbom2e000w2evztr73e5mi',NULL,179.00,'2026-06-22 14:54:27.605'),('cmqpc6kux001a2ea9jfpapkqu','cmqpbom2r00162evzqjn6asfv',NULL,299.00,'2026-06-22 14:54:27.609'),('cmqpc6kv0001e2ea9lggz50yf','cmqpbom2r00162evzqjn6asfv',NULL,320.00,'2026-06-22 14:54:27.612'),('cmqpc6kv5001k2ea970z908zm','cmqpbom33001g2evz15ytxzog',NULL,1290.00,'2026-06-22 14:54:27.617'),('cmqpc6kv9001o2ea9ofgagp9w','cmqpbom33001g2evz15ytxzog',NULL,1350.00,'2026-06-22 14:54:27.621'),('cmqpc6kvc001s2ea99y718z99','cmqpbom33001g2evz15ytxzog',NULL,1190.00,'2026-06-22 14:54:27.624'),('cmqpc6kvi001y2ea9dcpzohqg','cmqpbom3i001u2evz7ij96oum',NULL,12900.00,'2026-06-22 14:54:27.630'),('cmqpc6kvl00222ea9r1j2nahs','cmqpbom3i001u2evz7ij96oum',NULL,13500.00,'2026-06-22 14:54:27.633'),('cmqsyn2ud000c2ecppeq3e86c','cmqpbom1900082evz6iiov08a',NULL,45900.00,'2026-06-25 03:46:27.493'),('cmqsyn2ui000g2ecpnasilgfc','cmqpbom1900082evz6iiov08a',NULL,46500.00,'2026-06-25 03:46:27.498'),('cmqsyn2uk000k2ecpmadavcty','cmqpbom1900082evz6iiov08a',NULL,45200.00,'2026-06-25 03:46:27.500'),('cmqsyn2uo000q2ecp62i2f9p5','cmqpbom25000m2evzs6dc60zi',NULL,38900.00,'2026-06-25 03:46:27.504'),('cmqsyn2uq000u2ecpa8wx7v0x','cmqpbom25000m2evzs6dc60zi',NULL,39500.00,'2026-06-25 03:46:27.506'),('cmqsyn2uu00102ecpnmu2eznq','cmqpbom2e000w2evztr73e5mi',NULL,199.00,'2026-06-25 03:46:27.510'),('cmqsyn2uw00142ecp1z3py5xm','cmqpbom2e000w2evztr73e5mi',NULL,179.00,'2026-06-25 03:46:27.512'),('cmqsyn2uy001a2ecpbka0dx7m','cmqpbom2r00162evzqjn6asfv',NULL,299.00,'2026-06-25 03:46:27.514'),('cmqsyn2v0001e2ecp7oia82y8','cmqpbom2r00162evzqjn6asfv',NULL,320.00,'2026-06-25 03:46:27.516'),('cmqsyn2v2001k2ecp7zx1p7i9','cmqpbom33001g2evz15ytxzog',NULL,1290.00,'2026-06-25 03:46:27.518'),('cmqsyn2v4001o2ecpcyu0a3vx','cmqpbom33001g2evz15ytxzog',NULL,1350.00,'2026-06-25 03:46:27.520'),('cmqsyn2v7001s2ecpv4p3bu0f','cmqpbom33001g2evz15ytxzog',NULL,1190.00,'2026-06-25 03:46:27.523'),('cmqsyn2va001y2ecpnbyxv26a','cmqpbom3i001u2evz7ij96oum',NULL,12900.00,'2026-06-25 03:46:27.526'),('cmqsyn2vb00222ecpmxebn2o2','cmqpbom3i001u2evz7ij96oum',NULL,13500.00,'2026-06-25 03:46:27.527'),('cmqszfxbb000c2ebjniv66nuf','cmqpbom1900082evz6iiov08a',NULL,45900.00,'2026-06-25 04:08:53.350'),('cmqszfxbf000g2ebjhoizrlnt','cmqpbom1900082evz6iiov08a',NULL,46500.00,'2026-06-25 04:08:53.355'),('cmqszfxbk000k2ebjlloxqt77','cmqpbom1900082evz6iiov08a',NULL,45200.00,'2026-06-25 04:08:53.359'),('cmqszfxbo000q2ebjzsxpupch','cmqpbom25000m2evzs6dc60zi',NULL,38900.00,'2026-06-25 04:08:53.364'),('cmqszfxbr000u2ebjx3jaev9s','cmqpbom25000m2evzs6dc60zi',NULL,39500.00,'2026-06-25 04:08:53.367'),('cmqszfxbv00102ebjsmwaeldk','cmqpbom2e000w2evztr73e5mi',NULL,199.00,'2026-06-25 04:08:53.371'),('cmqszfxbx00142ebjomwdzfj5','cmqpbom2e000w2evztr73e5mi',NULL,179.00,'2026-06-25 04:08:53.373'),('cmqszfxc0001a2ebj74i56kcd','cmqpbom2r00162evzqjn6asfv',NULL,299.00,'2026-06-25 04:08:53.376'),('cmqszfxc3001e2ebjszkr5b6n','cmqpbom2r00162evzqjn6asfv',NULL,320.00,'2026-06-25 04:08:53.379'),('cmqszfxc7001k2ebj4bpkmoeq','cmqpbom33001g2evz15ytxzog',NULL,1290.00,'2026-06-25 04:08:53.383'),('cmqszfxc9001o2ebjjoxqc3ur','cmqpbom33001g2evz15ytxzog',NULL,1350.00,'2026-06-25 04:08:53.385'),('cmqszfxcb001s2ebj07lra00t','cmqpbom33001g2evz15ytxzog',NULL,1190.00,'2026-06-25 04:08:53.387'),('cmqszfxce001y2ebjln77a8bd','cmqpbom3i001u2evz7ij96oum',NULL,12900.00,'2026-06-25 04:08:53.390'),('cmqszfxci00222ebje6jkakei','cmqpbom3i001u2evz7ij96oum',NULL,13500.00,'2026-06-25 04:08:53.394');
/*!40000 ALTER TABLE `price_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_listings`
--

DROP TABLE IF EXISTS `product_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_listings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marketplace` enum('SHOPEE','LAZADA','TIKTOK_SHOP','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `original_price` decimal(12,2) DEFAULT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'THB',
  `affiliate_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_url` text COLLATE utf8mb4_unicode_ci,
  `rating` decimal(3,2) DEFAULT NULL,
  `sold_count` int NOT NULL DEFAULT '0',
  `stock` int DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT '1',
  `last_synced_at` datetime(3) DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_listings_marketplace_external_id_key` (`marketplace`,`external_id`),
  KEY `product_listings_product_id_idx` (`product_id`),
  KEY `product_listings_marketplace_idx` (`marketplace`),
  KEY `product_listings_price_idx` (`price`),
  CONSTRAINT `product_listings_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_listings`
--

LOCK TABLES `product_listings` WRITE;
/*!40000 ALTER TABLE `product_listings` DISABLE KEYS */;
INSERT INTO `product_listings` VALUES ('cmqpbom1l000a2evznbzw6w65','cmqpbom1900082evz6iiov08a','SHOPEE','shopee-iphone15','iPhone 15 Pro Max 256GB',45900.00,48900.00,'THB','https://shopee.co.th/product/shopee-iphone15?aff=dealhub','Apple Official Store',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.337','2026-06-25 05:40:39.596'),('cmqpbom1v000e2evzp27ju8x4','cmqpbom1900082evz6iiov08a','LAZADA','lazada-iphone15','iPhone 15 Pro Max 256GB',46500.00,48900.00,'THB','https://lazada.co.th/product/lazada-iphone15?aff=dealhub','Lazada Apple',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.348','2026-06-25 05:40:39.602'),('cmqpbom1z000i2evzvmte7w4e','cmqpbom1900082evz6iiov08a','TIKTOK_SHOP','tiktok-iphone15','iPhone 15 Pro Max 256GB',45200.00,48900.00,'THB','https://tiktok_shop.co.th/product/tiktok-iphone15?aff=dealhub','TikTok Apple TH',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.351','2026-06-25 05:40:39.605'),('cmqpbom27000o2evziahx0vp7','cmqpbom25000m2evzs6dc60zi','SHOPEE','shopee-s24','Samsung Galaxy S24 Ultra',38900.00,42900.00,'THB','https://shopee.co.th/product/shopee-s24?aff=dealhub','Samsung Official',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.360','2026-06-25 05:40:39.612'),('cmqpbom2b000s2evzwjf2a4fc','cmqpbom25000m2evzs6dc60zi','LAZADA','lazada-s24','Samsung Galaxy S24 Ultra',39500.00,42900.00,'THB','https://lazada.co.th/product/lazada-s24?aff=dealhub','Samsung Lazada',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.363','2026-06-25 05:40:39.615'),('cmqpbom2h000y2evzokm44fng','cmqpbom2e000w2evztr73e5mi','SHOPEE','shopee-tshirt','เสื้อยืด Oversize คอตตอน 100%',199.00,399.00,'THB','https://shopee.co.th/product/shopee-tshirt?aff=dealhub','Fashion TH',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.369','2026-06-25 05:40:39.637'),('cmqpbom2m00122evz7rl49131','cmqpbom2e000w2evztr73e5mi','TIKTOK_SHOP','tiktok-tshirt','เสื้อยืด Oversize คอตตอน 100%',179.00,399.00,'THB','https://tiktok_shop.co.th/product/tiktok-tshirt?aff=dealhub','TikTok Fashion',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.374','2026-06-25 05:40:39.639'),('cmqpbom2u00182evz9ksy5w12','cmqpbom2r00162evzqjn6asfv','SHOPEE','shopee-serum','เซรั่มวิตามินซี บำรุงผิว',299.00,590.00,'THB','https://shopee.co.th/product/shopee-serum?aff=dealhub','Beauty Store',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.382','2026-06-25 05:40:39.645'),('cmqpbom2z001c2evzjttj7ugk','cmqpbom2r00162evzqjn6asfv','LAZADA','lazada-serum','เซรั่มวิตามินซี บำรุงผิว',320.00,590.00,'THB','https://lazada.co.th/product/lazada-serum?aff=dealhub','Lazada Beauty',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.387','2026-06-25 05:40:39.646'),('cmqpbom36001i2evz2rtrb6ni','cmqpbom33001g2evz15ytxzog','SHOPEE','shopee-headphone','หูฟัง Bluetooth ANC Pro',1290.00,2490.00,'THB','https://shopee.co.th/product/shopee-headphone?aff=dealhub','Audio Shop',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.394','2026-06-25 05:40:39.630'),('cmqpbom3a001m2evzeehzgrwp','cmqpbom33001g2evz15ytxzog','LAZADA','lazada-headphone','หูฟัง Bluetooth ANC Pro',1350.00,2490.00,'THB','https://lazada.co.th/product/lazada-headphone?aff=dealhub','Lazada Audio',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.398','2026-06-25 05:40:39.631'),('cmqpbom3e001q2evzcm6a46z0','cmqpbom33001g2evz15ytxzog','TIKTOK_SHOP','tiktok-headphone','หูฟัง Bluetooth ANC Pro',1190.00,2490.00,'THB','https://tiktok_shop.co.th/product/tiktok-headphone?aff=dealhub','TikTok Audio',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.402','2026-06-25 05:40:39.632'),('cmqpbom3k001w2evz2u1gi7ob','cmqpbom3i001u2evz7ij96oum','SHOPEE','shopee-sofa','โซฟา 3 ที่นั่ง ผ้ากำมะหยี่',12900.00,18900.00,'THB','https://shopee.co.th/product/shopee-sofa?aff=dealhub','Home Furniture',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.408','2026-06-25 05:40:39.658'),('cmqpbom3n00202evzfsv0h1fo','cmqpbom3i001u2evz7ij96oum','LAZADA','lazada-sofa','โซฟา 3 ที่นั่ง ผ้ากำมะหยี่',13500.00,18900.00,'THB','https://lazada.co.th/product/lazada-sofa?aff=dealhub','Lazada Home',NULL,NULL,0,NULL,1,NULL,'2026-06-22 14:40:29.412','2026-06-25 05:40:39.659'),('cmqt1ekgm000m2ekn1ctzoeph','cmqpbom25000m2evzs6dc60zi','TIKTOK_SHOP','tiktok-s24','Samsung Galaxy S24 Ultra',38400.00,42900.00,'THB','https://tiktok_shop.co.th/product/tiktok-s24?aff=dealhub','Samsung TikTok',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.270','2026-06-25 05:40:39.618'),('cmqt1ekgu000q2eknw3i0r09o','cmqt1ekgp000o2eknc4ujh14l','SHOPEE','shopee-ipad-air','iPad Air M2 128GB Wi-Fi',22900.00,25900.00,'THB','https://shopee.co.th/product/shopee-ipad-air?aff=dealhub','iStudio TH',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.278','2026-06-25 05:40:39.623'),('cmqt1ekgw000s2eknuvu1sk13','cmqt1ekgp000o2eknc4ujh14l','LAZADA','lazada-ipad-air','iPad Air M2 128GB Wi-Fi',23400.00,25900.00,'THB','https://lazada.co.th/product/lazada-ipad-air?aff=dealhub','Lazada Apple',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.281','2026-06-25 05:40:39.624'),('cmqt1ekgy000w2eknt85ngx72','cmqt1ekgx000u2eknut3qd0ut','SHOPEE','shopee-ps5','PlayStation 5 Slim Digital',14990.00,17990.00,'THB','https://shopee.co.th/product/shopee-ps5?aff=dealhub','GamePro TH',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.283','2026-06-25 05:40:39.626'),('cmqt1ekgz000y2ekn0x6677hj','cmqt1ekgx000u2eknut3qd0ut','LAZADA','lazada-ps5','PlayStation 5 Slim Digital',15490.00,17990.00,'THB','https://lazada.co.th/product/lazada-ps5?aff=dealhub','Lazada Gaming',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.283','2026-06-25 05:40:39.627'),('cmqt1ekh000102eknc7llydsz','cmqt1ekgx000u2eknut3qd0ut','TIKTOK_SHOP','tiktok-ps5','PlayStation 5 Slim Digital',14790.00,17990.00,'THB','https://tiktok_shop.co.th/product/tiktok-ps5?aff=dealhub','TikTok Game Hub',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.284','2026-06-25 05:40:39.628'),('cmqt1ekhb001c2ekn5yq2o3tw','cmqt1ekh9001a2eknae4orf8u','SHOPEE','shopee-dyson-v12','Dyson V12 Detect Slim',16900.00,21900.00,'THB','https://shopee.co.th/product/shopee-dyson-v12?aff=dealhub','Home Premium',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.295','2026-06-25 05:40:39.634'),('cmqt1ekhc001e2ekn54j0bmac','cmqt1ekh9001a2eknae4orf8u','LAZADA','lazada-dyson-v12','Dyson V12 Detect Slim',17400.00,21900.00,'THB','https://lazada.co.th/product/lazada-dyson-v12?aff=dealhub','Lazada Home',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.297','2026-06-25 05:40:39.635'),('cmqt1ekhj001o2ekn46az1hsc','cmqt1ekhi001m2ekn8lvm8ey5','SHOPEE','shopee-af1','Nike Air Force 1 Low White',2890.00,3990.00,'THB','https://shopee.co.th/product/shopee-af1?aff=dealhub','Sneaker House',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.304','2026-06-25 05:40:39.642'),('cmqt1ekhl001q2eknx6ujtbsu','cmqt1ekhi001m2ekn8lvm8ey5','LAZADA','lazada-af1','Nike Air Force 1 Low White',2990.00,3990.00,'THB','https://lazada.co.th/product/lazada-af1?aff=dealhub','Lazada Sport',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.305','2026-06-25 05:40:39.643'),('cmqt1ekhs00202ekn8kwltrjd','cmqt1ekhr001y2eknjfsewh9z','SHOPEE','shopee-4u2-lip','ลิปทินท์ 4U2 You Better',129.00,249.00,'THB','https://shopee.co.th/product/shopee-4u2-lip?aff=dealhub','4U2 Official',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.313','2026-06-25 05:40:39.648'),('cmqt1ekhu00222eknhp7lg213','cmqt1ekhr001y2eknjfsewh9z','TIKTOK_SHOP','tiktok-4u2-lip','ลิปทินท์ 4U2 You Better',119.00,249.00,'THB','https://tiktok_shop.co.th/product/tiktok-4u2-lip?aff=dealhub','TikTok Beauty',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.314','2026-06-25 05:40:39.649'),('cmqt1ekhx00262ekn0dd22uxt','cmqt1ekhv00242ekn5lic55zy','SHOPEE','shopee-stanley','Stanley Quencher 40oz',1590.00,2290.00,'THB','https://shopee.co.th/product/shopee-stanley?aff=dealhub','Outdoor Life',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.317','2026-06-25 05:40:39.651'),('cmqt1ekhy00282ekn6r542dpu','cmqt1ekhv00242ekn5lic55zy','LAZADA','lazada-stanley','Stanley Quencher 40oz',1690.00,2290.00,'THB','https://lazada.co.th/product/lazada-stanley?aff=dealhub','Lazada Outdoor',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.318','2026-06-25 05:40:39.652'),('cmqt1ekhz002c2ekn8w14slsq','cmqt1ekhy002a2ekncr1yxokq','SHOPEE','shopee-airfryer','หม้อทอดไร้น้ำมัน Philips HD9252',2790.00,3990.00,'THB','https://shopee.co.th/product/shopee-airfryer?aff=dealhub','Kitchen Pro',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.320','2026-06-25 05:40:39.653'),('cmqt1eki1002e2eknze7ps7p2','cmqt1ekhy002a2ekncr1yxokq','LAZADA','lazada-airfryer','หม้อทอดไร้น้ำมัน Philips HD9252',2890.00,3990.00,'THB','https://lazada.co.th/product/lazada-airfryer?aff=dealhub','Lazada Kitchen',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.321','2026-06-25 05:40:39.654'),('cmqt1eki4002g2ekn9z23bgwa','cmqt1ekhy002a2ekncr1yxokq','TIKTOK_SHOP','tiktok-airfryer','หม้อทอดไร้น้ำมัน Philips HD9252',2690.00,3990.00,'THB','https://tiktok_shop.co.th/product/tiktok-airfryer?aff=dealhub','TikTok Home',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.324','2026-06-25 05:40:39.656'),('cmqt1ekik002q2eknij8pxvcn','cmqt1ekii002o2eknsqkjmijh','SHOPEE','shopee-gaming-chair','เก้าอี้เกมมิ่ง Ergo Pro',4590.00,6990.00,'THB','https://shopee.co.th/product/shopee-gaming-chair?aff=dealhub','Game Setup TH',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.340','2026-06-25 05:40:39.661'),('cmqt1ekio002s2eknsfuyo9b0','cmqt1ekii002o2eknsqkjmijh','LAZADA','lazada-gaming-chair','เก้าอี้เกมมิ่ง Ergo Pro',4790.00,6990.00,'THB','https://lazada.co.th/product/lazada-gaming-chair?aff=dealhub','Lazada Office',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:03:49.344','2026-06-25 05:40:39.662'),('cmqt1ha1z002w2e4e7f2u9knu','cmqt1ha1w002u2e4eq83w0ihj','SHOPEE','shopee-aw-s9','Apple Watch Series 9 GPS 41mm',11900.00,13900.00,'THB','https://shopee.co.th/product/shopee-aw-s9?aff=dealhub','iStudio TH',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:05:55.751','2026-06-25 05:40:39.664'),('cmqt1ha21002y2e4e79r0e9fn','cmqt1ha1w002u2e4eq83w0ihj','LAZADA','lazada-aw-s9','Apple Watch Series 9 GPS 41mm',12100.00,13900.00,'THB','https://lazada.co.th/product/lazada-aw-s9?aff=dealhub','Lazada Apple',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:05:55.754','2026-06-25 05:40:39.665'),('cmqt1ha2600322e4e1sfvl41l','cmqt1ha2300302e4eau8cmnva','SHOPEE','shopee-xiaomi-vac','หุ่นยนต์ดูดฝุ่น Xiaomi Robot Vacuum',6990.00,9990.00,'THB','https://shopee.co.th/product/shopee-xiaomi-vac?aff=dealhub','Mi Store TH',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:05:55.758','2026-06-25 05:40:39.666'),('cmqt1ha2800342e4el7eq3rd8','cmqt1ha2300302e4eau8cmnva','TIKTOK_SHOP','tiktok-xiaomi-vac','หุ่นยนต์ดูดฝุ่น Xiaomi Robot Vacuum',6790.00,9990.00,'THB','https://tiktok_shop.co.th/product/tiktok-xiaomi-vac?aff=dealhub','TikTok Mi Official',NULL,NULL,0,NULL,1,NULL,'2026-06-25 05:05:55.760','2026-06-25 05:40:39.667');
/*!40000 ALTER TABLE `product_listings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `images` json DEFAULT NULL,
  `category_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `review_count` int NOT NULL DEFAULT '0',
  `sold_count` int NOT NULL DEFAULT '0',
  `is_trending` tinyint(1) NOT NULL DEFAULT '0',
  `is_top_selling` tinyint(1) NOT NULL DEFAULT '0',
  `search_keywords` text COLLATE utf8mb4_unicode_ci,
  `ai_review_summary` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_key` (`slug`),
  KEY `products_category_id_idx` (`category_id`),
  KEY `products_is_trending_idx` (`is_trending`),
  KEY `products_is_top_selling_idx` (`is_top_selling`),
  KEY `products_sold_count_idx` (`sold_count`),
  FULLTEXT KEY `products_name_search_keywords_idx` (`name`,`search_keywords`),
  CONSTRAINT `products_category_id_fkey` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('cmqpbom1900082evz6iiov08a','iPhone 15 Pro Max 256GB','iphone-15-pro-max-256gb',NULL,'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=400&q=80',NULL,'cmqpbom0z00022evz98qcokba','Apple',4.80,1250,8500,1,1,'iphone 15 pro max apple สมาร์ทโฟน',NULL,'2026-06-22 14:40:29.325','2026-06-25 05:40:39.591'),('cmqpbom25000m2evzs6dc60zi','Samsung Galaxy S24 Ultra','samsung-galaxy-s24-ultra',NULL,'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&q=80',NULL,'cmqpbom0z00022evz98qcokba','Samsung',4.70,980,6200,1,1,'samsung galaxy s24 ultra สมาร์ทโฟน','สรุปรีวิวสินค้า \"Samsung Galaxy S24 Ultra\" จาก 980 รีวิว:\nคะแนนเฉลี่ย 4.7/5 ขายแล้ว 6,200 ชิ้น\nพบใน SHOPEE, LAZADA\nแบรนด์: Samsung\nสินค้านี้ได้รับความนิยมในหมวดที่เกี่ยวข้อง ราคาแข่งขันได้ดีเมื่อเทียบกับแพลตฟอร์มอื่น แนะนำสำหรับผู้ที่มองหาคุณภาพในราคาที่คุ้มค่า','2026-06-22 14:40:29.358','2026-06-25 05:40:39.609'),('cmqpbom2e000w2evztr73e5mi','เสื้อยืด Oversize คอตตอน 100%','oversize-cotton-tshirt',NULL,'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&q=80',NULL,'cmqpbom1300032evzyzzrdjo7','Local Brand',4.50,3200,15000,1,1,'เสื้อยืด oversize แฟชั่น',NULL,'2026-06-22 14:40:29.367','2026-06-25 05:40:39.636'),('cmqpbom2r00162evzqjn6asfv','เซรั่มวิตามินซี บำรุงผิว','vitamin-c-serum',NULL,'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&q=80',NULL,'cmqpbom1400052evz8s5b55h2','Beauty Pro',4.60,5600,22000,1,0,'เซรั่ม วิตามินซี บำรุงผิว ความงาม','สรุปรีวิวสินค้า \"เซรั่มวิตามินซี บำรุงผิว\" จาก 5600 รีวิว:\nคะแนนเฉลี่ย 4.6/5 ขายแล้ว 22,000 ชิ้น\nพบใน SHOPEE, LAZADA\nแบรนด์: Beauty Pro\nสินค้านี้ได้รับความนิยมในหมวดที่เกี่ยวข้อง ราคาแข่งขันได้ดีเมื่อเทียบกับแพลตฟอร์มอื่น แนะนำสำหรับผู้ที่มองหาคุณภาพในราคาที่คุ้มค่า','2026-06-22 14:40:29.379','2026-06-25 05:40:39.644'),('cmqpbom33001g2evz15ytxzog','หูฟัง Bluetooth ANC Pro','bluetooth-anc-headphones',NULL,'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80',NULL,'cmqpbom0z00022evz98qcokba','SoundMax',4.40,2100,9800,1,1,'หูฟัง bluetooth anc ไร้สาย','สรุปรีวิวสินค้า \"หูฟัง Bluetooth ANC Pro\" จาก 2100 รีวิว:\nคะแนนเฉลี่ย 4.4/5 ขายแล้ว 9,800 ชิ้น\nพบใน SHOPEE, LAZADA, TIKTOK_SHOP\nแบรนด์: SoundMax\nสินค้านี้ได้รับความนิยมในหมวดที่เกี่ยวข้อง ราคาแข่งขันได้ดีเมื่อเทียบกับแพลตฟอร์มอื่น แนะนำสำหรับผู้ที่มองหาคุณภาพในราคาที่คุ้มค่า','2026-06-22 14:40:29.392','2026-06-25 05:40:39.629'),('cmqpbom3i001u2evz7ij96oum','โซฟา 3 ที่นั่ง ผ้ากำมะหยี่','velvet-sofa-3-seater',NULL,'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&q=80',NULL,'cmqpbom1300042evzytiqje7k','HomeStyle',4.30,450,1200,0,1,'โซฟา บ้าน เฟอร์นิเจอร์','สรุปรีวิวสินค้า \"โซฟา 3 ที่นั่ง ผ้ากำมะหยี่\" จาก 450 รีวิว:\nคะแนนเฉลี่ย 4.3/5 ขายแล้ว 1,200 ชิ้น\nพบใน SHOPEE, LAZADA\nแบรนด์: HomeStyle\nสินค้านี้ได้รับความนิยมในหมวดที่เกี่ยวข้อง ราคาแข่งขันได้ดีเมื่อเทียบกับแพลตฟอร์มอื่น แนะนำสำหรับผู้ที่มองหาคุณภาพในราคาที่คุ้มค่า','2026-06-22 14:40:29.406','2026-06-25 05:40:39.657'),('cmqt1ekgp000o2eknc4ujh14l','iPad Air M2 128GB Wi-Fi','ipad-air-m2-128gb',NULL,'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b5?w=400&q=80',NULL,'cmqpbom0z00022evz98qcokba','Apple',4.80,740,5100,1,1,'ipad air m2 แท็บเล็ต apple',NULL,'2026-06-25 05:03:49.274','2026-06-25 05:40:39.620'),('cmqt1ekgx000u2eknut3qd0ut','PlayStation 5 Slim Digital','playstation-5-slim-digital',NULL,'https://images.unsplash.com/photo-1606813907293-d86efa9b94db?w=400&q=80',NULL,'cmqpbom0z00022evz98qcokba','Sony',4.90,2100,4300,1,1,'ps5 playstation 5 คอนโซลเกม',NULL,'2026-06-25 05:03:49.282','2026-06-25 05:40:39.625'),('cmqt1ekh9001a2eknae4orf8u','Dyson V12 Detect Slim','dyson-v12-detect-slim',NULL,'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=400&q=80',NULL,'cmqpbom1300042evzytiqje7k','Dyson',4.70,890,3200,1,1,'dyson v12 เครื่องดูดฝุ่น ไร้สาย',NULL,'2026-06-25 05:03:49.293','2026-06-25 05:40:39.633'),('cmqt1ekhi001m2ekn8lvm8ey5','Nike Air Force 1 Low White','nike-air-force-1-low',NULL,'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&q=80',NULL,'cmqpbom1300032evzyzzrdjo7','Nike',4.60,1800,7600,1,1,'nike air force 1 รองเท้า สเนกเกอร์',NULL,'2026-06-25 05:03:49.302','2026-06-25 05:40:39.640'),('cmqt1ekhr001y2eknjfsewh9z','ลิปทินท์ 4U2 You Better','4u2-lip-tint-you-better',NULL,'https://images.unsplash.com/photo-1586495777744-4413d210d8fc?w=400&q=80',NULL,'cmqpbom1400052evz8s5b55h2','4U2',4.50,4200,18500,1,1,'ลิปทินท์ 4u2 เครื่องสำอาง',NULL,'2026-06-25 05:03:49.311','2026-06-25 05:40:39.647'),('cmqt1ekhv00242ekn5lic55zy','Stanley Quencher 40oz','stanley-quencher-40oz',NULL,'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&q=80',NULL,'cmqpbom1500062evzih8qqaoj','Stanley',4.70,2900,11200,1,1,'stanley กระบอกน้ำ tumbler',NULL,'2026-06-25 05:03:49.315','2026-06-25 05:40:39.650'),('cmqt1ekhy002a2ekncr1yxokq','หม้อทอดไร้น้ำมัน Philips HD9252','philips-air-fryer-hd9252',NULL,'https://images.unsplash.com/photo-1585515320310-259814833e62?w=400&q=80',NULL,'cmqpbom1300042evzytiqje7k','Philips',4.60,3500,8900,1,1,'หม้อทอดไร้น้ำมัน air fryer philips',NULL,'2026-06-25 05:03:49.319','2026-06-25 05:40:39.652'),('cmqt1ekii002o2eknsqkjmijh','เก้าอี้เกมมิ่ง Ergo Pro','ergo-pro-gaming-chair',NULL,'https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=400&q=80',NULL,'cmqpbom1500062evzih8qqaoj','ErgoPro',4.40,680,2400,0,1,'เก้าอี้เกมมิ่ง เก้าอี้ทำงาน',NULL,'2026-06-25 05:03:49.338','2026-06-25 05:40:39.660'),('cmqt1ha1w002u2e4eq83w0ihj','Apple Watch Series 9 GPS 41mm','apple-watch-series-9-41mm',NULL,'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400&q=80',NULL,'cmqpbom0z00022evz98qcokba','Apple',4.80,920,3800,0,1,'apple watch series 9 นาฬิกาอัจฉริยะ',NULL,'2026-06-25 05:05:55.748','2026-06-25 05:40:39.663'),('cmqt1ha2300302e4eau8cmnva','หุ่นยนต์ดูดฝุ่น Xiaomi Robot Vacuum','xiaomi-robot-vacuum-s10',NULL,'https://images.unsplash.com/photo-1558317374-067fb5f30001?w=400&q=80',NULL,'cmqpbom1300042evzytiqje7k','Xiaomi',4.50,1100,4100,0,1,'หุ่นยนต์ดูดฝุ่น xiaomi robot vacuum',NULL,'2026-06-25 05:05:55.756','2026-06-25 05:40:39.665');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `role_permissions_permission_id_fkey` (`permission_id`),
  CONSTRAINT `role_permissions_permission_id_fkey` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_permissions_role_id_fkey` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_key` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_logs`
--

DROP TABLE IF EXISTS `search_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_logs` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `results` int NOT NULL DEFAULT '0',
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `search_logs_query_idx` (`query`),
  KEY `search_logs_created_at_idx` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_logs`
--

LOCK TABLES `search_logs` WRITE;
/*!40000 ALTER TABLE `search_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trending_keywords`
--

DROP TABLE IF EXISTS `trending_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trending_keywords` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyword` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int NOT NULL DEFAULT '1',
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trending_keywords_keyword_key` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trending_keywords`
--

LOCK TABLES `trending_keywords` WRITE;
/*!40000 ALTER TABLE `trending_keywords` DISABLE KEYS */;
INSERT INTO `trending_keywords` VALUES ('cmqpbom3s00232evza4kw2bmu','iphone',859,'2026-06-25 05:40:39.668'),('cmqpbom3x00242evzdc5v390w','samsung',488,'2026-06-25 05:40:39.669'),('cmqpbom3z00252evz9ul967ws','เสื้อยืด',629,'2026-06-25 05:40:39.670'),('cmqpbom4100262evz0atg86it','เซรั่ม',825,'2026-06-25 05:40:39.671'),('cmqpbom4300272evzm2m39ifw','หูฟัง',635,'2026-06-25 05:40:39.672'),('cmqpbom4700282evzy311puuw','โซฟา',809,'2026-06-25 05:40:39.673'),('cmqpbom4900292evz4cb066g9','สมาร์ทโฟน',774,'2026-06-25 05:40:39.673'),('cmqpbom4b002a2evzl98sz3o3','แฟชั่น',727,'2026-06-25 05:40:39.674'),('cmqt1ekje00312ekn5hg4opcg','ps5',253,'2026-06-25 05:40:39.675'),('cmqt1ekjf00322eknhhkb2f90','stanley',400,'2026-06-25 05:40:39.675'),('cmqt1ekjg00332eknhv5f152g','dyson',428,'2026-06-25 05:40:39.676'),('cmqt1ekji00342eknw9ug2nty','air fryer',277,'2026-06-25 05:40:39.676');
/*!40000 ALTER TABLE `trending_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('USER','ADMIN','SUPER_ADMIN') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USER',
  `status` enum('ACTIVE','INACTIVE','BANNED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `email_verified` tinyint(1) NOT NULL DEFAULT '0',
  `refresh_token` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updated_at` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('cmqpbom0m00002evzbp5z1pdh','admin@dealhub.th','$2b$12$yc2jyGnp9XSHObXzLPDsB.9jDeVTfIs4zoTECHEXGPFnbzVSs9SBe','ผู้ดูแลระบบ',NULL,'SUPER_ADMIN','ACTIVE',1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjbXFwYm9tMG0wMDAwMmV2emJwNXoxcGRoIiwiZW1haWwiOiJhZG1pbkBkZWFsaHViLnRoIiwicm9sZSI6IlNVUEVSX0FETUlOIiwiaWF0IjoxNzgyMzYxNjEzLCJleHAiOjE3ODI5NjY0MTN9.i_VVAMYZfglg_DHvtYvwOleDV31bYKmE4qMvRJbNYfE','2026-06-22 14:40:29.302','2026-06-25 04:26:53.423'),('cmqpbom0u00012evzje7n0twb','user@dealhub.th','$2b$12$DNi/Np5PTuJbhLstkgsni..zlzSaes8tsMyVnoUkB0YBuzxA.6lyi','สมชาย ใจดี',NULL,'USER','ACTIVE',1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJjbXFwYm9tMHUwMDAxMmV2emplN24wdHdiIiwiZW1haWwiOiJ1c2VyQGRlYWxodWIudGgiLCJyb2xlIjoiVVNFUiIsImlhdCI6MTc4MjM2NDgzNSwiZXhwIjoxNzgyOTY5NjM1fQ.ZLHbAm5BQhaIA2iJcUp5ZJKYs8HDr-_sXx-dKphxVps','2026-06-22 14:40:29.310','2026-06-25 05:20:35.586'),('cmqt2py8j003h2el9d9q3cqwa','arpakorn@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','อาภากร ค.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.956','2026-06-25 05:40:39.956'),('cmqt2py8o003i2el9an3gwzfd','nattaya@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','ณัฐญา ท.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.960','2026-06-25 05:40:39.960'),('cmqt2py8p003j2el9h8f7d49g','prasan@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','ประสาน ส.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.961','2026-06-25 05:40:39.961'),('cmqt2py8r003k2el9t3ujcvrk','kwanchai@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','ขวัญชัย ว.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.963','2026-06-25 05:40:39.963'),('cmqt2py8s003l2el98ifbrxp2','mint@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','มิ้นท์ พ.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.965','2026-06-25 05:40:39.965'),('cmqt2py8u003m2el9jeamvx6j','boy@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','บอย ด.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.966','2026-06-25 05:40:39.966'),('cmqt2py8v003n2el95vzbw8r6','fah@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','ฟ้า ส.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.968','2026-06-25 05:40:39.968'),('cmqt2py8x003o2el9jodfe56j','ploy@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','พลอย จ.',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.969','2026-06-25 05:40:39.969'),('cmqt2py8y003p2el9obn02xbi','dealhunter@dealhub.th','$2b$12$PDZd74u.Om8b/xUkuKU4TeBVJSzgb.qsUzUphq.kfCpbCmjVKWcba','Deal Hunter',NULL,'USER','ACTIVE',1,NULL,'2026-06-25 05:40:39.971','2026-06-25 05:40:39.971');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlists` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_user_id_product_id_key` (`user_id`,`product_id`),
  KEY `wishlists_product_id_fkey` (`product_id`),
  CONSTRAINT `wishlists_product_id_fkey` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wishlists_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'dealhub_th'
--
